﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {

    public float movementSpeed;

    private bool movingLeft;
	public static bool isAlive = true;
	public float sideMax = 2f;
	public float sideSpeed = 1f;
	public int turnRadius = 7;

    private void Start()
    {
        
        movingLeft = true;

    }

    private void Update()
    {

        transform.TransformVector(Vector3.down * Time.deltaTime * movementSpeed);

        //Player movement
        if(Input.GetMouseButtonDown(0))
        {
            movingLeft = !movingLeft;
        }

		if (movingLeft) { // smooth direction change
			if (sideSpeed > -sideMax) {
				sideSpeed -=  sideMax / turnRadius;
			}
		} else {
			if (sideSpeed < sideMax) {
				sideSpeed += sideMax / turnRadius;
			}
		}

		transform.Translate (sideSpeed * Time.deltaTime, -movementSpeed * Time.deltaTime, 0);



    }

    private void OnTriggerEnter(Collider other)
    {
        if(other.tag == "Obstacle")
        {
			isAlive = false;
            Die();
        }
    }

    void Die()
    {
        print("Player Dead.");
        Destroy(this.gameObject);
    }
}
