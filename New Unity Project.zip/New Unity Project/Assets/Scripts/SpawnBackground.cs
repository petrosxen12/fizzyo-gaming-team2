﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnBackground : MonoBehaviour 
{
	public GameObject background;
	public bool spawned;

	void OnTriggerEnter(Collider other)
	{
		if(other.tag == "Player" && !spawned)
		{
			Vector3 pos = new Vector3 (transform.parent.position.x, (transform.parent.position.y - 25), transform.parent.position.z);
			Instantiate (background.transform, pos, transform.parent.rotation);
			spawned = true;
		}
	}		
}
