﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObstaclesSpawning : MonoBehaviour {

    public GameObject player;

    public GameObject obstacle;
    public float amountOfObstacles;

    public float minX, maxX;

    public void Start()
    {
        player = GameObject.FindWithTag("Player");

        for (int i = 0; i < amountOfObstacles; i++)
        {
            float xAxis,yAxis;

            xAxis = Random.Range(minX, maxX);
            yAxis = Random.Range(player.transform.localPosition.y - 10, transform.localPosition.y - 30);

            Vector3 pos = new Vector3(xAxis,yAxis,0);
            Instantiate(obstacle.transform,pos,Quaternion.identity);

        }
    }


}
