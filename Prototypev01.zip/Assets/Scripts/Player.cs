﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {

    public float score;
    public float movementSpeed;

    public float rotationSpeed;
    private bool movingLeft;

    private void Start()
    {
        score = 0f;
        movingLeft = true;
    }

    private void Update()
    {
        //score += Time.deltaTime;
        score += 1f;
        //print("Score: %f",score);
        Debug.Log("Score: "+score);
        transform.Translate(Vector3.down * Time.deltaTime * movementSpeed);

        //Player movement
        if(Input.GetMouseButtonDown(0))
        {
            rotationSpeed = 1.5f;
            //rotationSpeed = 4f;
            movingLeft = !movingLeft;
        }

        //if(Input.GetMouseButton(0))
        //{
        //    rotationSpeed += 2f * Time.deltaTime;
        //    //rotationSpeed += 4f;
        //}

        if(movingLeft)
        {
            transform.Rotate(0,0,rotationSpeed);
        }else{
            transform.Rotate(0,0,-rotationSpeed);
        }

    }

    private void OnTriggerEnter(Collider other)
    {
        if(other.tag == "Obstacle")
        {
            Die();
        }
    }

    void Die()
    {
        print("Player Dead.");
        Destroy(this.gameObject);
    }
}
